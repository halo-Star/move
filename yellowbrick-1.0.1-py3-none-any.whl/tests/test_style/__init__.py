# tests.test_style
# Tests for the style handling module of yellowbrick.
#
# Author:   Benjamin Bengfort <bbengfort@districtdatalabs.com>
# Created:  Tue Oct 04 16:21:21 2016 -0400
#
# Copyright (C) 2016 The scikit-yb developers
# For license information, see LICENSE.txt
#
# ID: __init__.py [c6aff34] benjamin@bengfort.com $

"""
Tests for the style handling module of yellowbrick.
"""

##########################################################################
## Imports
##########################################################################
