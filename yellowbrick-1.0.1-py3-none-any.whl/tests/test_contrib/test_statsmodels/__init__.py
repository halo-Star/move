# tests.test_contrib.test_statsmodels
# Tests for the statsmodels contrib package
#
# Author:  Benjamin Bengfort <benjamin@bengfort.com>
# Created: Wed Apr 04 13:28:13 2018 -0400
#
# ID: __init__.py [d6ebc39] benjamin@bengfort.com $

"""
Tests for the statsmodels contrib package
"""

##########################################################################
## Imports
##########################################################################
