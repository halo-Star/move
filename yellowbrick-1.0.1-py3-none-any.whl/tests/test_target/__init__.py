# tests.test_target
# Tests for the target module.
#
# Author:  Benjamin Bengfort <benjamin@bengfort.com>
# Created: Thu Jul 19 09:09:07 2018 -0400
#
# ID: __init__.py [d742c57] benjamin@bengfort.com $

"""
Tests for the target module.
"""

##########################################################################
## Imports
##########################################################################
