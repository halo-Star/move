# tests.test_utils
# Tests for Yellowbrick utilities
#
# Author:   Benjamin Bengfort <bbengfort@districtdatalabs.com>
# Created:  Thu May 18 15:15:05 2017 -0400
#
# Copyright (C) 2017 The scikit-yb developers
# For license information, see LICENSE.txt
#
# ID: __init__.py [79cd8cf] benjamin@bengfort.com $

"""
Tests for Yellowbrick utilities
"""

##########################################################################
## Imports
##########################################################################
