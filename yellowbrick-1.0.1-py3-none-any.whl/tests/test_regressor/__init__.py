# tests.test_regressor
# Tests for the regressor visualizers.
#
# Author:   Benjamin Bengfort <bbengfort@districtdatalabs.com>
# Created:  Mon Mar 06 22:01:34 2017 -0500
#
# Copyright (C) 2016 The scikit-yb developers
# For license information, see LICENSE.txt
#
# ID: __init__.py [7d3f5e6] benjamin@bengfort.com $

"""
Tests for the regressor visualizers.
"""

##########################################################################
## Imports
##########################################################################
