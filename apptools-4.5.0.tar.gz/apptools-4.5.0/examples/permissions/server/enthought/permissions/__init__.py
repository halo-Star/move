#------------------------------------------------------------------------------
# Copyright (c) 2007 by Enthought, Inc.
# All rights reserved.
#------------------------------------------------------------------------------

try:
    __import__('pkg_resources').declare_namespace(__name__)
except:
    pass

