AppTools Documentation
==============================================

.. toctree::
    :maxdepth: 2
    :glob:
      
    appscripting/*
    permissions/Introduction
    permissions/ApplicationAPI
    permissions/DefaultPolicyManagerDataAPI
    permissions/DefaultUserManagerDataAPI
    preferences/*
    scripting/*
    undo/*
    selection/*
      
* :ref:`search`
