#------------------------------------------------------------------------------
# Copyright (c) 2007 by Enthought, Inc.
# All rights reserved.
#------------------------------------------------------------------------------
""" Supports creating templatizable object hierarchies.
    Part of the AppTools project of the Enthought Tool Suite.
"""
