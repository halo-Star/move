class InvalidProviderError(Exception):
    pass
